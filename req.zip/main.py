import chainlit as cl
import openai 
import os
from openai import OpenAI




os.environ['OPENAI_API_KEY']='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'
client = OpenAI()

@cl.on_message
async def main(message:cl.Message):
    msg= message.content
    response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
                {"role":"assistant","content":"you are a helpful assistant"},
                {"role":"user", "content":msg}
    ],
    temperature=1
    )
    result=response.choices[0].message.content
    await cl.Message(content=result).send()
    